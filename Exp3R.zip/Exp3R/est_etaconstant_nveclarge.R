rm(list=ls())

# set your working directory
setwd("C:/Users/Ec/OneDrive/Documents/Th�se/Exp3R")
library(DEoptim)
source("myfunctions.R")


### computation of the estimators for the boxplots for constant eta.

nvec = c(500,2000*(1:15))
lvec=length(nvec)
pi = c(0.8,0)
eta= 0.3
Nsimu=1000
est_mat = matrix(0, ncol=Nsimu, nrow=lvec)


for(i in 1:lvec)
{
  start=Sys.time()
  for(nsimu in 1:Nsimu)
  {
    arms=Exp3(nvec[i],pi,eta)[[1]]
    est_mat[i,nsimu]=MLE(arms,pi,c(0.1,0.8))
    cat(paste("n=",nvec[i], "nsimu=", nsimu),file="output.txt",sep="\n",append=TRUE) 
  }
  end=Sys.time()
  cat(paste("time for Nsimu=",end-start),file="output.txt",sep="\n",append=TRUE)
}

save(est_mat,file='Data_eta03_nveclarge1.Rdata')
