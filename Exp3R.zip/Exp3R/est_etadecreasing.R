rm(list=ls())


# set your working directory
setwd("C:/Users/julie/OneDrive/Documents/Th�se/Exp3R")

library(DEoptim)
source("myfunctions.R")


### computation of the estimators for the boxplots for 2 or 4 arms for a decreasing eta.

nvec = c(500,2000*(1:15))
lvec=length(nvec)
#pi = c(0.8,0)
pi=c(0.8,0.6,0.4,0.2)
eta0= 0.3
Nsimu=1000
est_mat = matrix(0, ncol=Nsimu, nrow=lvec)
Tmax_mat= matrix(0, ncol=Nsimu, nrow=lvec)
pred_err= matrix(0, ncol=Nsimu, nrow=lvec)
epsilon=10^(-7)
nbreaks=50

for(i in 1:lvec)
{
  start=Sys.time()
  n=nvec[i]
  range=c(0.1,0.8)/(sqrt(n)*pi[1])
  eta=eta0/(sqrt(n)*pi[1])

  for(nsimu in 1:Nsimu)
  {
    n=nvec[i]
    arms=Exp3(n,pi,eta)[[1]]
    a=MLE_truncated(arms,pi,range,epsilon,nbreaks)
    est_mat[i,nsimu]=a[[1]]
    Tmax_mat[i,nsimu]=a[[2]]
    vrai_prob=prob_delta(arms[1:a[[2]]],eta,pi)[[1]]
    est_prob=prob_delta(arms[1:a[[2]]],a[[1]],pi)[[1]]
    pred_err[i,nsimu]=mean((est_prob-vrai_prob)^2)
    cat(paste("n=",nvec[i], "nsimu=", nsimu),file="output1.txt",sep="\n",append=TRUE)  
  }
  end=Sys.time()
  cat(paste("time for Nsimu=",end-start),file="output1.txt",sep="\n",append=TRUE)
}

res=list(est_mat,Tmax_mat,pred_err)
#save(res,file='Data_eta03_dec1.Rdata')
save(res,file='Data_eta03_dec_K41.Rdata')
