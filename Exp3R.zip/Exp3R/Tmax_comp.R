rm(list=ls())



## set your working directory
setwd("")


library(DEoptim)
source("myfunctions.R")


K=4
pi=c(0.8,0.6,0.4,0.2)
nvec = c(500,2000*(1:15))
ln=length(nvec)
deltavec=seq(0.1,0.8,length.out=50)
ld=length(deltavec)
epsvec=c(0.01,0.001,10^(-7),10^(-15),10^(-30))
le=length(epsvec)
Nsim=1000
ld=length(deltavec)
Tmax=array(0,dim = c(ln,Nsim,ld,le))

eta0=0.3

for(indn in 1:ln)
{
  n=nvec[indn]
  eta=eta0/(sqrt(n)*pi[1])
  for(nsim in 1:Nsim)
  {  
    arms=Exp3(n,pi,eta)[[1]]
    for(d in 1:ld)
    {
      Tmax[indn,nsim,d,]=prob_delta(arms,deltavec[d]/(sqrt(n)*pi[1]),pi,epsilon=epsvec)[[2]]
      print(c(n,nsim,d))
    }
  }
}  


#save(res,file='Data_eta03_dec.Rdata')
save(Tmax,file='Tmax_eta03_dec_K4.Rdata')
save(Tmax,file='Tmax_eta03_dec_K41.Rdata')
